"""Rebuild the smooth positive mould STEP with editable proportions.

Requirements: Python 3, cadquery 2.7, numpy, scipy.
Run: python rebuild_plaster.py
Output: PLASTER_rebuilt.step alongside this script.
Units: nominal mm. Z is superior; the femoral head centre is the origin.
"""
from pathlib import Path
import numpy as np
import cadquery as cq
from scipy.interpolate import make_interp_spline
from OCP.gp import gp_Pnt
from OCP.Geom import Geom_BSplineSurface
from OCP.TColgp import TColgp_Array2OfPnt
from OCP.TColStd import TColStd_Array1OfReal, TColStd_Array1OfInteger
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace, BRepBuilderAPI_Sewing, BRepBuilderAPI_MakeSolid
from OCP.TopoDS import TopoDS

# Editable design parameters. A factor of 1.0 reproduces the delivered design.
WIDTH_FACTOR = 1.0
DEPTH_FACTOR = 1.0
HEIGHT_FACTOR = 1.0
LATERAL_EXTENSION_FACTOR = 1.0
MOULD_VERTICAL_OFFSET_MM = -1.2

def arr(values, cls):
    out=cls(1,len(values))
    for i,v in enumerate(values):out.SetValue(i+1,v.item() if hasattr(v,'item') else v)
    return out

def make_mould():
    theta=np.arange(256)*2*np.pi/256
    ct,st=np.cos(theta),np.sin(theta);w=((1-ct)/2)**4
    rows=[]
    for z,cx,rx,ry in [(-302,3,0,0),(-302,3,15,13),(-295,3,32,28),(-280,3,44,38),(-250,3,50,44),(-200,0,54,47),(-145,-1,59,52),(-100,-3,65,57),(-80,-2.5,69.5,60)]:
        rows.append(np.column_stack([cx+rx*ct,ry*st,np.full(256,z)]))
    for cx,rx,ry,z,bump in [(.5,79.5,61,-53,40),(6,78,60,-40,60),(16,70,58,-35,105),(16,62,52,-36,110),(16,53,44,-48,94),(16,40,32,-65,44),(16,22,19,-76,10),(16,0,0,-76,0)]:
        rows.append(np.column_stack([cx+rx*ct,ry*st,z+bump*w*LATERAL_EXTENSION_FACTOR]))
    controls=np.asarray(rows)
    parameter=np.r_[0,np.cumsum(np.mean(np.linalg.norm(np.diff(controls,axis=0),axis=2),axis=1))]
    d0=np.column_stack([ct,.87*st,np.zeros(256)])
    d1=np.column_stack([-ct,-.86*st,np.zeros(256)])
    scale=np.array([WIDTH_FACTOR,DEPTH_FACTOR,HEIGHT_FACTOR])
    controls*=scale;controls[:,:,2]+=MOULD_VERTICAL_OFFSET_MM
    d0*=scale;d1*=scale
    v=make_interp_spline(parameter,controls,axis=0,bc_type=([(1,d0)],[(1,d1)]))
    step=2*np.pi/256
    deriv=(np.roll(v.c,-1,axis=1)-np.roll(v.c,1,axis=1))/(2*step)
    sewing=BRepBuilderAPI_Sewing(1e-5)
    for quadrant in range(4):
        ids=np.arange(quadrant*64,(quadrant+1)*64+1,4)%256
        angles=np.arange(quadrant*64,(quadrant+1)*64+1,4)*step
        u=make_interp_spline(angles,v.c[:,ids,:].transpose(1,0,2),axis=0,bc_type=([(1,deriv[:,ids[0],:])],[(1,deriv[:,ids[-1],:])]))
        cp=u.c;poles=TColgp_Array2OfPnt(1,cp.shape[0],1,cp.shape[1])
        for i in range(cp.shape[0]):
            for j in range(cp.shape[1]):poles.SetValue(i+1,j+1,gp_Pnt(*cp[i,j]))
        uk,um=np.unique(u.t,return_counts=True);vk,vm=np.unique(v.t,return_counts=True)
        surf=Geom_BSplineSurface(poles,arr(uk,TColStd_Array1OfReal),arr(vk,TColStd_Array1OfReal),arr(um,TColStd_Array1OfInteger),arr(vm,TColStd_Array1OfInteger),3,3)
        sewing.Add(BRepBuilderAPI_MakeFace(surf,1e-6).Face())
    sewing.Perform();shell=cq.Shape.cast(sewing.SewedShape()).Shells()[0]
    solid=cq.Solid(BRepBuilderAPI_MakeSolid(shell.wrapped).Solid())
    if solid.Volume()<0:solid=cq.Solid(TopoDS.Solid_s(solid.wrapped.Reversed()))
    assert solid.isValid() and len(solid.Solids())==1
    return solid

if __name__=='__main__':
    shape=make_mould();output=Path(__file__).with_name('PLASTER_rebuilt.step')
    cq.exporters.export(shape,str(output))
    reopened=cq.importers.importStep(str(output)).val()
    assert reopened.isValid() and len(reopened.Solids())==1
    print(f'Saved {output}: 1 valid solid, {len(reopened.Faces())} smooth faces, volume {reopened.Volume():.3f} mm^3')
