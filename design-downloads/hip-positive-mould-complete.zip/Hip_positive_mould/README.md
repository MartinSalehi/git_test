# Hip, femur and solid positive mould

Open **ASSEMBLY_hip_femur_positive_mould.step** for the three aligned CAD bodies. Each body is also supplied separately. All files use the same coordinates, so import them without automatic centring or individual scaling.

## What changed

- The femoral head and acetabulum were fitted from the supplied bone surfaces and aligned at a common centre.
- Both bones were mirrored to match the illustrated side and posed to reproduce the reference's general arrangement. The original bone scale was retained.
- The femur was shortened and capped for the reference assembly. **FEMUR_full_length_aligned** retains the full bone as a separate alternative; it is longer than this mould.
- The plaster was substantially rebuilt: a rounded high lateral extension, lower medial rim, closed saddle-shaped top, tapered body and rounded distal end. It is a **filled positive mould**, not a hollow shell.
- The hip's main connected anatomical surface was retained; small disconnected scan debris and degenerate slivers were removed.

## Files

| File | Contents |
| --- | --- |
| ASSEMBLY_hip_femur_positive_mould.step | Named, coloured assembly with three independent solid bodies |
| PLASTER_smooth_solid.step | One CAD solid bounded by four smooth B-spline faces |
| HIP_aligned.step | One closed faceted CAD solid derived from the hip scan |
| FEMUR_reference_stump.step | One closed faceted CAD solid for the shortened femur |
| FEMUR_full_length_aligned.step | Alternative full-length femur CAD solid |
| Corresponding .stl files | Dense, closed meshes; same alignment as the STEP files |
| Hip_and_positive_mould.blend | Editable Blender scene with the bodies, cameras and a hidden cutaway display object |
| rebuild_plaster.py | Standalone CAD reconstruction script with editable width, depth, height and lateral-extension factors |
| 01_reference_cutaway.png | Anatomy-visible sectioned preview; the delivered mould remains solid |
| 02–06 PNG views | Front, oblique, isolated mould, aligned bones and side views |
| 07_silhouette_check.png | Final projected contours compared with an approximate hand trace of the supplied reference |
| Validation JSON files | Topology, STEP round-trip, sampled deviation and containment results |

The bone STEP files have planar B-rep faces. They are genuine solid bodies, but they are not smooth reverse-engineered anatomical NURBS surfaces. The plaster STEP is smooth. Large bone STEP files may take time to import.

## Size and coordinates

Nominal units are **millimetres**, inferred from the supplied bones. The source STL files contain no unit metadata, and no measured calibration dimension was supplied. The femoral head radius is approximately 25.44 mm and the fitted acetabular radius approximately 27.31 mm.

The mould is approximately **168 mm wide × 123 mm deep × 376 mm high**. The head centre is at the origin; Z points upward. The frontal reference view looks along positive Y, with the lateral extension on the left.

The bones intentionally overlap the filled positive mould in this anatomical arrangement, including the contained lower pelvis. The assembly is not fused. A sectioned display is used to expose the anatomy in the preview; that display object is not the mould manufacturing geometry.

## Checks

- Every delivered STL is a single connected, watertight surface with consistent outward winding, positive volume and no degenerate triangles.
- The smooth plaster passes OpenCascade's topology and self-interference checks.
- The bone CAD conversions preserve scan detail to less than 0.45 mm maximum **sampled** bidirectional deviation. This is a sampling result, not a certified global Hausdorff bound.
- The portion of the shortened femur below Z = -90 mm is fully within the positive mould, with roughly 19 mm minimum vertex-to-surface clearance in the final mesh check.
- Individual STEP solids and the assembled STEP are checked after reopening. See `cad_validation_final.json` for the final results.
- The plaster reconstruction script was run independently and its resulting STEP was reopened as a valid single solid.

## Editing the plaster

Install Python packages `cadquery`, `numpy`, and `scipy`, then run:

```sh
python rebuild_plaster.py
```

Default factors reproduce the delivered mould. Change the factors near the top of the script to adjust proportions, then rerun. The output is `PLASTER_rebuilt.step`. Recheck the anatomical relationship after changing any dimension.

This is a reference-based concept model. Clinical fit, pressure distribution, fabrication allowances and suitability for use on a person have not been validated.
